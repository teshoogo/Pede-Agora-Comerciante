
var krms_config ={					
	'ApiUrl':"http://pedeagora.hospteste.ga/merchantapp/api",
	'DialogDefaultTitle':"Notificação",
	'APIHasKey':"o654asd4sadsfs879fsd3v21xczvc8as7dsda5f45s6ad4f65asdf87g",
	'debug': false
};